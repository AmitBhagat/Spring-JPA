package com.sboot.ticketbooking.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sboot.ticketbooking.dao.PersonDao;
import com.sboot.ticketbooking.model.Person;

@Service
public class PersonService {
	
	
	@Autowired
	private PersonDao personDao;
	
	public Iterable<Person> savePersons(Iterable<Person> persons){
		
		return personDao.saveAll(persons);
	}
	
	
	public Iterable<Person> getPersons(Iterable<Integer> personIds){
		
		return personDao.findAllById(personIds);
	}
	
	public List<Person> findByFirstName(String firstName){
		return personDao.findByFirstName(firstName);
	}

	
	public Person findByFirstNameAndLastName(String firstName, String lastName) {
		return personDao.findByFirstNameAndLastName(firstName,lastName);
	}
	
	
	public List<Person> findByFirstNameOrLastName(String firstName, String lastName){
		return personDao.findByFirstNameOrLastName(firstName,lastName);
	}
	
	
	public List<Person> findByLastNameOrderByCreatedDateDesc(String lastName){
		return personDao.findByLastNameOrderByCreatedDateDesc(lastName);
	}
	
	
	public List<Person> findByAgeLessThanEqual(Integer age){
		return personDao.findByAgeLessThanEqual(age);
	}
	
	
	public List<Person> findByFirstNameLike(String firstName){
		return personDao.findByFirstNameLike(firstName);
	}
	
	
	public List<Person> findByLastNameAndAgeLessThanEqual(String lastName,int Age){
		return personDao.findByLastNameAndAgeLessThanEqual(lastName,Age);
	}
	
	
	public List<Person> findByCreatedDateBetween(Date startdate,Date endDate){
		return personDao.findByCreatedDateBetween(startdate,endDate);
	}
}
