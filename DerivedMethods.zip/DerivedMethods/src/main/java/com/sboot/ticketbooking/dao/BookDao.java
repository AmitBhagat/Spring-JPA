package com.sboot.ticketbooking.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sboot.ticketbooking.model.Book;

@Repository
public interface BookDao extends CrudRepository<Book, Integer> {

}
