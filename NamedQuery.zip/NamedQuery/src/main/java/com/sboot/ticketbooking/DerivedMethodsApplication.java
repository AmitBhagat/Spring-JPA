package com.sboot.ticketbooking;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.sboot.ticketbooking.model.Person;
import com.sboot.ticketbooking.service.PersonService;

@SpringBootApplication
public class DerivedMethodsApplication implements CommandLineRunner{

	
	@Autowired
	private PersonService personService;
	
	public static void main(String[] args) {
		SpringApplication.run(DerivedMethodsApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		//createPersons();
		//getPersonByIds();
		//getPersons();
		//findByFirstNameAndLastName();
		//findByFirstNameOrLastName();
		//findByLastNameOrderByCreationDateDesc();
		//findByAgeLessThanEqual();
		//findByLastNameAndAgeLessThanEqual();
		//findByFirstNameLike();
		//findByCreatedDateBetween();
		//findByCreatedDateBetweenwithTime();
		//searchbyfirstname();
		searchbybothnames();
	}

	
	private void createPersons() {
		
		
		
		

		/*
		 * List<Person> personList=new ArrayList<Person>();
		 * 
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 * 
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 * 
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 */

		List<Person> personList = Arrays.asList(
				new Person("Kiran", "kumar", "kiran@gmail.com", 20),
				new Person("Ram", "kumar", "ram@gmail.com", 22),
				new Person("RamKiran", "LaxmiKiran", "sita@gmail.com", 30),
				new Person("Lakshamn", "Seth", "seth@gmail.com", 50),
				new Person("Sita", "Kumar", "lakshman@gmail.com", 50),
				new Person("Ganesh", "Kumar", "ganesh@gmail.com", 50),
				new Person("KiranKiran", "kumar", "kiran@gmail.com", 20),
				new Person("RamRam", "kumar", "ram@gmail.com", 22),
				new Person("RamKiranRamKiran", "LaxmiKiran", "sita@gmail.com", 30),
				new Person("RamKiranRamKiran", "Seth", "seth@gmail.com", 50),
				new Person("SitaSita", "Kumar", "lakshman@gmail.com", 50),
				new Person("GaneshSita", "Kumar", "ganesh@gmail.com", 50)
				);

		Iterable<Person> list = personService.savePersons(personList);
		for (Person person : list) {
			System.out.println("Person Object" + person.toString());

		}
	}

	
	private void getPersonByIds() {
		List<Integer> personList = new ArrayList<Integer>();
		personList.add(1);
		personList.add(2);
		personList.add(12);
		personList.add(5);
		personList.add(6);
		personList.add(20);
		personList.add(40);
		personList.add(11);
		personList.add(15);
		personList.add(3);
		personList.add(4);
		Iterable<Person> personsList = personService.getPersons(personList);
		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}
	}
	
	private void getPersons()
	{
		Iterable<Person> personsList=personService.findByFirstName("Kiran");
		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}
	}
	
	
	
	
	
	private void findByFirstName() {
		Iterable<Person> personsList = personService.findByFirstName("Ram");
		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}
	}

	private void findByFirstNameAndLastName() {
		Person person = personService.findByFirstNameAndLastName("Ram", "kumar");

		System.out.println("Person Object" + person.toString());

	}

	// findByFirstNameAndLastName

	private void findByFirstNameOrLastName() {
		Iterable<Person> personsList = personService.findByFirstNameOrLastName("Sita", "kumar");

		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}

	}
	
	// findByLastNameOrderByCreationDateDesc
		private void findByLastNameOrderByCreationDateDesc() {
			Iterable<Person> personsList = personService.findByLastNameOrderByCreatedDateDesc("kumar");

			for (Person person : personsList) {
				System.out.println("Person Object" + person.toString());

			}

		}
		

	// findByAgeLessThanEqual

	private void findByAgeLessThanEqual() {
		Iterable<Person> personsList = personService.findByAgeLessThanEqual(40);

		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}

	}

	
	private void findByLastNameAndAgeLessThanEqual() {
		Iterable<Person> personsList = personService.findByLastNameAndAgeLessThanEqual("kumar",40);

		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}

	}
	

	private void findByFirstNameLike() {
		Iterable<Person> personList = personService.findByFirstNameLike("%Kiran%");

		for (Person person : personList) {
			System.out.println(person.toString());
		}
	}

	

	

	
	private Date getDatewithTime(String dateString) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		try {
			return format.parse(dateString);
		} catch (ParseException pe) {
			throw new RuntimeException(pe);
		}
	}
	
	
	private Date getDate(String dateString) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		try {
			return format.parse(dateString);
		} catch (ParseException pe) {
			throw new RuntimeException(pe);
		}
	}

	private Date getDate(String dateString, int add) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		try {
			Date current = format.parse(dateString);

			Calendar cal = Calendar.getInstance();
			cal.setTime(current);
			cal.add(Calendar.DATE, add);

			return cal.getTime();
		} catch (ParseException pe) {
			throw new RuntimeException(pe);
		}
	}

	private void findByCreatedDateBetweenwithTime() {
		//2020-05-22 07:43:51.175000
		Iterable<Person> personsList = personService.findByCreatedDateBetween(
				getDatewithTime("2020-10-16 07:27:42"), 
				getDatewithTime("2020-10-16 07:27:45"));

		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}

	}
	

	private void findByCreatedDateBetween() {
		Iterable<Person> personsList = personService.findByCreatedDateBetween(
				getDate("2020-10-13"), 
				getDate("2020-10-17"));

		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}

	}
	
	private void searchbyfirstname() {
		Iterable<Person> personsList = personService.searchbyfirstname("Ram");
		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}
	}

	private void searchbybothnames() {
		Person person = personService.searchbybothnames("Ram", "kumar");

		System.out.println("Person Object" + person.toString());

	}
	
}
