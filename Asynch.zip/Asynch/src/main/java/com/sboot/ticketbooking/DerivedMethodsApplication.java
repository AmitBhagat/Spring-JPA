package com.sboot.ticketbooking;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.TaskExecutor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.sboot.ticketbooking.model.Person;
import com.sboot.ticketbooking.service.PersonService;

@SpringBootApplication
@EnableAsync
public class DerivedMethodsApplication implements CommandLineRunner{

	
	@Autowired
	private PersonService personService;
	
	public static void main(String[] args) {
		SpringApplication.run(DerivedMethodsApplication.class, args);
	}

	//Following code will be used for customization of theadpool async
	//configuration. Its optional
	@Bean("asyncthreadpool")
	public TaskExecutor getAsyncExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(2);
		executor.setMaxPoolSize(3);
		executor.setWaitForTasksToCompleteOnShutdown(false);
		executor.setThreadNamePrefix("AsyncThread-");
		System.out.println("Async Thread Pool Log");
		return executor;

	}
	
	private void dynamicUpdateTest() {
		Person person = personService.findById(1);
		person.setEmail("a@b.com");
		//update person set age=60 where id=1
		personService.save(person);

		System.out.println("After update Person Object" + person.toString());

	}
	@Override
	public void run(String... args) throws Exception {
		
		//createPersons();
		//getPersonByIds();
		//getPersons();
		//findByFirstNameAndLastName();
		//findByFirstNameOrLastName();
		//findByLastNameOrderByCreationDateDesc();
		//findByAgeLessThanEqual();
		//findByLastNameAndAgeLessThanEqual();
		//findByFirstNameLike();
		//findByCreatedDateBetween();
		//findByCreatedDateBetweenwithTime();
		//searchbyfirstname();
		//searchbybothnames();
		//findPersonInfobyFirstNameorEmail();
		//findPersonINfobyFirstname();
		//dispPagination();
		//runsync();
		//runAsync();
		dynamicUpdateTest();
	}

	
	private void createPersons() {
		
		
		
		

		/*
		 * List<Person> personList=new ArrayList<Person>();
		 * 
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 * 
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 * 
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 * personList.add(new Person("Kiran", "kumar", "kiran@gmail.com", 20));
		 */

		List<Person> personList = Arrays.asList(
				new Person("Kiran", "kumar", "kiran@gmail.com", 20),
				new Person("Ram", "kumar", "ram@gmail.com", 22),
				new Person("RamKiran", "LaxmiKiran", "sita@gmail.com", 30),
				new Person("Lakshamn", "Seth", "seth@gmail.com", 50),
				new Person("Sita", "Kumar", "lakshman@gmail.com", 50),
				new Person("Ganesh", "Kumar", "ganesh@gmail.com", 50),
				new Person("KiranKiran", "kumar", "kiran@gmail.com", 20),
				new Person("RamRam", "kumar", "ram@gmail.com", 22),
				new Person("RamKiranRamKiran", "LaxmiKiran", "sita@gmail.com", 30),
				new Person("RamKiranRamKiran", "Seth", "seth@gmail.com", 50),
				new Person("SitaSita", "Kumar", "lakshman@gmail.com", 50),
				new Person("GaneshSita", "Kumar", "ganesh@gmail.com", 50)
				);

		Iterable<Person> list = personService.savePersons(personList);
		for (Person person : list) {
			System.out.println("Person Object" + person.toString());

		}
	}

	
	private void getPersonByIds() {
		List<Integer> personList = new ArrayList<Integer>();
		personList.add(1);
		personList.add(2);
		personList.add(12);
		personList.add(5);
		personList.add(6);
		personList.add(20);
		personList.add(40);
		personList.add(11);
		personList.add(15);
		personList.add(3);
		personList.add(4);
		Iterable<Person> personsList = personService.getPersons(personList);
		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}
	}
	
	private void getPersons()
	{
		Iterable<Person> personsList=personService.findByFirstName("Kiran");
		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}
	}
	
	
	
	
	
	private void findByFirstName() {
		Iterable<Person> personsList = personService.findByFirstName("Ram");
		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}
	}

	private void findByFirstNameAndLastName() {
		Person person = personService.findByFirstNameAndLastName("Ram", "kumar");

		System.out.println("Person Object" + person.toString());

	}

	// findByFirstNameAndLastName

	private void findByFirstNameOrLastName() {
		Iterable<Person> personsList = personService.findByFirstNameOrLastName("Sita", "kumar");

		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}

	}
	
	// findByLastNameOrderByCreationDateDesc
		private void findByLastNameOrderByCreationDateDesc() {
			Iterable<Person> personsList = personService.findByLastNameOrderByCreatedDateDesc("kumar");

			for (Person person : personsList) {
				System.out.println("Person Object" + person.toString());

			}

		}
		

	// findByAgeLessThanEqual

	private void findByAgeLessThanEqual() {
		Iterable<Person> personsList = personService.findByAgeLessThanEqual(40);

		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}

	}

	
	private void findByLastNameAndAgeLessThanEqual() {
		Iterable<Person> personsList = personService.findByLastNameAndAgeLessThanEqual("kumar",40);

		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}

	}
	

	private void findByFirstNameLike() {
		Iterable<Person> personList = personService.findByFirstNameLike("%Kiran%");

		for (Person person : personList) {
			System.out.println(person.toString());
		}
	}

	

	

	
	private Date getDatewithTime(String dateString) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		try {
			return format.parse(dateString);
		} catch (ParseException pe) {
			throw new RuntimeException(pe);
		}
	}
	
	
	private Date getDate(String dateString) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		try {
			return format.parse(dateString);
		} catch (ParseException pe) {
			throw new RuntimeException(pe);
		}
	}

	private Date getDate(String dateString, int add) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		try {
			Date current = format.parse(dateString);

			Calendar cal = Calendar.getInstance();
			cal.setTime(current);
			cal.add(Calendar.DATE, add);

			return cal.getTime();
		} catch (ParseException pe) {
			throw new RuntimeException(pe);
		}
	}

	private void findByCreatedDateBetweenwithTime() {
		//2020-05-22 07:43:51.175000
		Iterable<Person> personsList = personService.findByCreatedDateBetween(
				getDatewithTime("2020-10-16 07:27:42"), 
				getDatewithTime("2020-10-16 07:27:45"));

		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}

	}
	

	private void findByCreatedDateBetween() {
		Iterable<Person> personsList = personService.findByCreatedDateBetween(
				getDate("2020-10-13"), 
				getDate("2020-10-17"));

		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}

	}
	
	private void searchbyfirstname() {
		Iterable<Person> personsList = personService.searchbyfirstname("Ram");
		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}
	}

	private void searchbybothnames() {
		Person person = personService.searchbybothnames("Ram", "kumar");

		System.out.println("Person Object" + person.toString());

	}
	private void findPersonInfobyFirstNameorEmail() {
		Iterable<Person> personsList = personService.
				findPersonInfobyFirstNameorEmail("Sita", "ganesh@gmail.com");

		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}

	}
	

	private void findPersonINfobyFirstname() {
		Iterable<Person> personsList = personService.
				findPersonINfobyFirstname("Sita");

		for (Person person : personsList) {
			System.out.println("Person Object" + person.toString());

		}

	}
	
	private void dispPagination()
	{
		
		
		
		System.out.println("Complete DAta");
		
		List<Person> orginalList = personService.findByLastName("kumar");
		
		orginalList.forEach(System.out::println);
		
		/*for (Person person : orginalList) {
			System.out.println("Person Object" + person.toString() );
			
		}*/
		
		
		System.out.println("First Page Without sorting ------------------------");
		
		List<Person> noSortList = personService.findByLastName("kumar",
				PageRequest.of(0, 4));
		
		
		/*
		 * for (Person person : noSortList) { System.out.println(person); }
		 */
		
		noSortList.forEach(System.out::println);
		
		
		System.out.println("First Page ------------------------");
		List<Person> list = personService.findByLastName("kumar",
				PageRequest.of(0, 2, Direction.ASC,"firstName"));
		
		//SELECT * FROM PERSON WHERE LAST_NAME=? WHERE ROWNUMBER>=0 AND RWONUMBER<=4
		 //ORDER BY FIRSTAME ASC;
		
		//0 -> Offset
		//4 -> Page Size
		//Order of Sorting ASC/DESC
		//Which column Name order 
		
		//for (Person person : list) {
		//	System.out.println("Person Object" + person.toString());
		//}
		
		list.forEach(System.out::println);
		
		
		System.out.println("Second Page ------------------------");
		List<Person> secondlist = personService.findByLastName("kumar",
				//new PageRequest(1, 2, Direction.ASC, "firstName"));
				PageRequest.of(1,2, Direction.ASC, "firstName"));
		
		secondlist.forEach(System.out::println);
			
		
		System.out.println("Third Page ------------------------");
		List<Person> thirdlist = personService.findByLastName("kumar",
				PageRequest.of(2,2, Direction.ASC,"firstName"));
		
		thirdlist.forEach(System.out::println);
		
		
		System.out.println("Fourth Page ------------------------");
		List<Person> fourthList = personService.findByLastName("kumar",
				PageRequest.of(3, 2, Direction.ASC,"firstName"));
		
		fourthList.forEach(System.out::println);
		
		
	}
	
	
	private void runsync()  {

		long start = System.currentTimeMillis();
		// Kick of multiple, asynchronous lookups
		List<Person> person1 = personService.findByEmail("kiran@gmail.com");
		// The following statement will be printed only after the
		// execution of above method findByEmail
		System.out.println("Person1 Call Completed");

		List<Person> personson2 = personService.findByEmail("laxmikiran@gmail.com");
		System.out.println("Person2 Call Completed");

		List<Person> personson3 = personService.findByEmail("sita@gmail.com");
		System.out.println("personson3 Call Completed");

		List<Person> personson4 = personService.findByEmail("lakshman@gmail.com");
		System.out.println("personson4 Call Completed");
		

		// Wait until they are all done
		// Print results, including elapsed time

		person1.forEach(System.out::println);
		personson2.forEach(System.out::println);

		personson3.forEach(System.out::println);

		personson4.forEach(System.out::println);

		System.out.println("Total Time took: " + (System.currentTimeMillis() - start));

	}

	private void runAsync() throws InterruptedException, ExecutionException {
		long start = System.currentTimeMillis();
		// Kick of multiple, asynchronous lookups

		// main Thread is executing the runAsynch method
		CompletableFuture<Person> obj1 = personService.findByemail("kiran@gmail.com");
		System.out.println("Person1 Call Done");

		CompletableFuture<Person> obj2 = personService.findByemail("laxmikiran@gmail.com");
		System.out.println("Person2 Call Done");

		CompletableFuture<Person> obj3 = personService.findByemail("sita@gmail.com");
		System.out.println("Person3 Call Done");

		CompletableFuture<Person> obj4 = personService.findByemail("lakshman@gmail.com");
		System.out.println("Person4 Call Done"); //This work given to Thrad4  by Main Thread
		
		///
	 //	1000 lines of code
		
		//obj2
		
		
		

		// Wait until they are all done
		CompletableFuture.allOf(obj1, obj2, obj3, obj4).join();
		
		// Print results, including elapsed time
	
		System.out.println("--> " + obj1.get());
		System.out.println("--> " + obj2.get());
		System.out.println("--> " + obj3.get());
		System.out.println("--> " + obj4.get());
		
		System.out.println("Elapsed time: " + (System.currentTimeMillis() - start));
	}
	
}
